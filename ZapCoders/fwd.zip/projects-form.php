
<form id="projects-form" class="project-form" style="width: 500px; margin: 20px auto;">
  <div id="form-inputs">
    <div class="form-group">
      <label for="duration">Name and Description</label>
      <input type="text" class="form-control" id="duration" placeholder="" required>
    </div>
    <div class="form-group">
      <label for="domain">Domain of your project</label>
      <select class="form-control" id="domain">
        <option value="Front-End Development">Front End</option>
        <option value="Back-End Development">Back End</option>
        <option value="IOS App Development">IOS</option>
        <option value="Android App Development">Android app development</option>
        <option value="Windows App Development">Windows app development</option>
        <option value="Hybrid App Development">Hybrid Development</option>
        <option value="Game Development">Game Development</option>
        <option value="Desktop Application Development">Desktop apps Development</option>
        <option value="Database Development">Database Development</option>
        <option value="AI/ML/DL">AI/ML/DL</option>
        <option value="Big Data">Big Data</option>
        <option value="Cloud Computing">Cloud Computing</option>
        <option value="Computer Security">Computer Security</option>
        <option value="IOT">IOT</option>
      </select>
    </div>
    <div class="form-group">
      <label for="tech">Technologies used</label>
      <input type="text" class="form-control" id="tech" placeholder="html, css, javascript" required>
    </div>
    <div class="form-group">
      <label for="tech">Github Link</label>
      <input type="url" class="form-control" id="tech">
    </div>

  </div>

  <a onclick="add()">Add New Project</a><br>
  <button type="submit" id="submit" class="btn btn-primary">Submit</button>
</form>
