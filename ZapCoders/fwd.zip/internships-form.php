
<form id="internship-form" class="applicant-form" style="width: 500px; margin: 20px auto;">
  <div id="form-inputs">
    <div class="form-group">
      <label for="domain">Company Name</label>
      <select class="form-control" id="domain">
        <option value="google">Google</option>
        <option value="facebook">Facebook</option>
        <option value="oracle">Oracle</option>
        <option value="microsoft">Microsoft</option>
        <option value="amazon">Amazon</option>
        <option value="flipkart">Flipkart</option>
        <option value="apple">Apple</option>
        <option value="twitter">Twitter</option>
        <option value="tcs">TCS</option>
        <option value="infosys">infosys</option>
        <option value="ivp">Indus Valley Partner</option>
        <option value="morgan-stanley">Morgan Stanley</option>
        <option value="other">Other</option>
      </select>
    </div>
    <div class="form-group">
      <label for="tech">Technology used</label>
      <input type="text" class="form-control" id="tech" placeholder="html, css, javascript" required>
    </div>
    <div class="form-group">
      <label for="duration">Duration (in months)</label>
      <input type="text" class="form-control" id="duration" placeholder="" required>
    </div>
  </div>

  <a onclick="add()">Add New Internship</a><br>
  <button type="submit" id="submit" class="btn btn-primary">Submit</button>
</form>
