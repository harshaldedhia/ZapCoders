
<form id="skills-form" class="applicant-form" style="width: 500px; margin: 20px auto;">
  <div id="form-inputs">
    <div class="form-group">
      <label for="domain">Domain of your skill</label>
      <select class="form-control" id="domain">
        <option value="Front-End Development">Front End</option>
        <option value="Back-End Development">Back End</option>
        <option value="IOS App Development">IOS</option>
        <option value="Android App Development">Android app development</option>
        <option value="Windows App Development">Windows app development</option>
        <option value="Hybrid App Development">Hybrid Development</option>
        <option value="Game Development">Game Development</option>
        <option value="Desktop Application Development">Desktop apps Development</option>
        <option value="Database Development">Database Development</option>
        <option value="AI/ML/DL">AI/ML/DL</option>
        <option value="Big Data">Big Data</option>
        <option value="Cloud Computing">Cloud Computing</option>
        <option value="Computer Security">Computer Security</option>
        <option value="IOT">IOT</option>
      </select>
    </div>
    <div class="form-group">
      <label for="tech">Technology known</label>
      <select class="form-control" id="tech">
        <option value="html">HTML</option>
        <option value="css">CSS</option>
        <option value="javascript">Javascript</option>
        <option value="c++">C++</option>
        <option value="c#">C#</option>
        <option value="c">C</option>
        <option value="python">Python</option>
        <option value="java">Java</option>
        <option value="kotlin">kotlin</option>
        <option value="nodejs">nodejs</option>
        <option value="bootstrap">bootstrap</option>
        <option value="ajax">ajax</option>
        <option value="php">php</option>
        <option value="oraclesql">oraclesql</option>
        <option value="mysql">mysql</option>
        <option value="mongodb">mongodb</option>
        <option value="unity">unity</option>
        <option value="unreal">unreal</option>
        <option value="cryengine">cryengine</option>
        <option value="objectivec">objective-c</option>
        <option value="swift">swift</option>
        <option value="linux">linux</option>
        <option value="scala">scala</option>
        <option value="hadoop">hadoop</option>
        <option value="spark">spark</option>
        <option value="enmap">enmap</option>
        <option value="metasploit">metasploit</option>
        <option value="raspberrypi">raspberrypi</option>
        <option value="arduino">arduino</option>
        <option value="robotics">robotics</option>
        <option value="tensorflow">tensorflow</option>
        <option value="keras">keras</option>
        <option value="pytorch">pytorch</option>
        <option value="naturallanguageprocessing">naturallanguageprocessing</option>
        <option value="computervision">computervision</option>
        <option value="statistics">statistics</option>
        <option value="deeplearning">deeplearning</option>
      </select>
    </div>
    <div class="form-group">
      <label for="grade">How far do you grade yourself?</label>
      <select class="form-control" id="grade">
        <option value="begineer">Begineer</option>
        <option value="intermediate">Intermediate</option>
        <option value="master">Master</option>
      </select>
    </div>
  </div>

  <a onclick="add()">Add New Skill</a><br>
  <button type="submit" id="submit" class="btn btn-primary">Submit</button>
</form>
